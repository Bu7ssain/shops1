Locales['en'] = {
  	['press_to_open'] = '<font face="sharlock">~r~H ﺮﺠﺘﻤﻟﺍ ﺓﺭﺍﺩﺇ ~y~E ﺮﺠﺘﻤﻟﺍ ﻕﻮﺴﺗ',
	['press_to_rob'] = '<font face="sharlock"> ﺮﺠﺘﻤﻟﺍ ﺔﻗﺮﺴﻟ ~y~E ~w~ﻂﻐﺿﺍ',
	['press_to_open_center'] = '<font face="sharlock"> ﺮﺠﺘﻣ ﺀﺍﺮﺸﻟ ~y~E ~w~ﻂﻐﺿﺍ',
	['name_shop'] = 'تسجيل اسم المتجر - يفضل بأحرف انجليزية',
	['buy_shop'] = 'شراء متجر ',
	['robbery_cancel'] = '<font color=red> تم إلغاء السرقة <font color=red> (لقد ذهبت بعيدا)',
	['set_price'] = 'تحديد قيمة السلعة',
	['how_much'] = 'ادخل كمية السلعة',
}
