bo7s = {
    oldRobSystem = false,
    SafeHealth  =  1000,
}