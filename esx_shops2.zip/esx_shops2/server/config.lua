Config                            = {}
Config.DrawDistance               = 20.0
Config.Locale = 'en'
Config.DeliveryTime = 1500 -- IN SECOUNDS DEFAULT (18000) IS 5 HOURS / 300 MINUTES
Config.TimeBetweenRobberies = 3600 -- 3 hours
Config.CutOnRobbery = 5 -- IN PERCENTAGE FROM THE TARGET SHOP
Config.RequiredPolices = 4 -- 4
Config.RequiredCriminals = 1
Config.SellValue = 2 -- This is the shops value divided by 2
Config.ChangeNamePrice = 25000 -- In $ - how much you can change the shops name for
Config.RobCooldown = 60 -- كم من الوقت يجب أن تنتظر لسرقة البقاله مرة أخرى بلدقائق
Config.AllRobCooldown = 15 -- كم من الوقت الانتظار بين السرقات
Config.MaxFoodTrucksItems = 200
Config.WeaponCraftTime = 0 * 0




Config.dublebox = 1

Config.BoxMax = {
  ['market'] = 40,
  ['bar'] = 15,
  ['pharmacie'] = 15,
  ['rts'] = 15,
  ['weapons'] = 15,
  ['SodaMachine'] = 10,
  ['truck'] = 10,
}

Config.addXpForBoxDelivery = 25

Config.Mazad = {
  xp = 35,
  H = 500000, -- حد اعلى
  L = 100000, -- حد ادنى
}

Config.Items = {
  ['market'] = { -- 30 متجر
    [1] = {label = "صندوق مياه معدنية", item = "waterbox", price = 1000, itemConvert = 'water', count = 20, max = 4000},
    [2] = {label = "صندوق برجر", item = "breadbox", price = 400, itemConvert = 'bread', count = 20, max = 4000},
   -- [3] = {label = "صندوق شوكلاتة", item = "chocolatebox", price = 500, itemConvert = 'chocolate', count =  30, max = 4000},
   -- [4] = {label = "صندوق كولا", item = "cocacolabox", price = 500, itemConvert = 'cocacola', count = 15, max = 4000},
   -- [5] = {label = "صندوق فطيرة", item = "cupcakebox", price = 700, itemConvert = 'cupcake', count = 25, max = 4000},
    [3] = {label = 'صندوق كاشف رادار', item = "speedcamera_detectorbox", price = 35000, itemConvert = 'speedcamera_detector', count = 10, max = 4000},
    [4] = {label = 'صندوق دريل', item = "drill_box", price = 40000, itemConvert = 'drill', count = 4, max = 4000},
    [5] = {label = 'صندوق قناع أكسجين', item = "oxygen_maskbox", price = 800, itemConvert = 'oxygen_mask', count = 10, max = 4000},
    [6] = {label = 'صندوق طعام حيوانات أليفة', item = "croquettes_box", price = 1000, itemConvert = 'croquettes', count = 10, max = 4000},
    [7] =  {label = 'صندوق عدة معادن', item = "m_toolbox", price = 2500, itemConvert = 'm_tool', count = 15, max = 4000},
    [8] = {label = 'صندوق عدة دواجن', item = "s_toolbox", price = 1500, itemConvert = 's_tool', count = 40, max = 4000},
    [9] = {label = 'صندوق عدة غاز', item = "f_toolbox", price = 3500, itemConvert = 'f_tool', count = 50, max = 4000},
    [10] = {label = 'صندوق عدة أخشاب', item = "l_toolbox", price = 1500, itemConvert = 'l_tool', count = 50, max = 4000},
   -- [13] = {label = 'صندوق عدة خضروات', item = "boxv_tool", price = 500, itemConvert = 'v_tool', count = 20, max = 4000},
    [11] = {label = 'صندوق عدة أقمشة', item = "t_toolbox", price = 1500, itemConvert = 't_tool', count = 50, max = 4000},
   -- [14] = {label = 'صندوق عدة أسمنت', item = "cement_kit_box", price = 1200, itemConvert = 'cement_kit', count = 10, max = 1500},
   -- [12] = {label = 'صندوق خيشة', item = "headbagbox", price = 2000, itemConvert = 'headbag', count = 10, max = 4000},
    [12] = {label = 'صندوق سنارة صيد سمك', item = "fs_box", price = 4000, itemConvert = 'fishingrod', count = 15, max = 4000},
    [13] = {label = 'صندوق طعم سلاحف بحرية', item = "fs2_box", price = 2000, itemConvert = 'turtlebait', count = 10, max = 4000},
    [14] = {label = 'صندوق طعم اسماك', item = "fishbaitbox", price = 2000, itemConvert = 'fishbait', count = 50, max = 4000},
    [15] = {label = 'صندوق لاب توب', item = "laptop_hbox", price = 160000, itemConvert = 'laptop_h', count = 8, max = 1000},
    --[17] = {label = 'صندوق شحنة حرارية', item = "thermal_charge_box", price = 15000, itemConvert = 'thermal_charge', count = 4, max = 100},
    [16] = {label = 'صندوق راديو', item = "radiobox", price = 4000, itemConvert = 'radio', count = 6, max = 4000},
   [17] = {label = "عدة سمكرة", item = "carokit_box", price = 3500, itemConvert = 'carokit', count = 10, max = 500, Storge = false},
   [18] = {label = 'صندوق عدة تصليح', item = "fixkit", price = 2000, itemConvert = 'fixkit', count = 40, max = 4000},
   [19] = {label = "صندوق سجائر", item = "cigarette_box", price = 150, itemConvert = 'cigarette', count = 20, max = 4000},
   [20] = {label = "صندوق ولاعات", item = "lighter_box", price = 300, itemConvert = 'lighter', count = 20, max = 4000},
   --[24] = {label = "كرتون شيبس", item = "chepsbox", price = 400, itemConvert = 'cheps', count = 25, max = 2000},
   --[21] = {label = "صندوق علبة تعبئة طلقات", item = "boxbig", price = 4000, itemConvert = 'clip', count = 35, max = 4000},
   [21] = {label = 'صندوق سترة مضادة للرصاص', item = "bulletproof_box", price = 1500, itemConvert = 'bulletproof', count = 15, max = 4000},
   [22] = {label = 'صندوق عدة سمكرة', item = "carokit_box", price = 1500, itemConvert = 'carotool', count = 15, max = 4000},

  },
  ['bar'] = { -- 4 بارات
    [1] = {label = "صندوق مياه معدنية", item = "waterbox", price = 900, itemConvert = 'water', count = 20, max = 1000},
   -- [2] = {label = "صندوق برجر", item = "breadbox", price = 150, itemConvert = 'bread', count = 20, max = 1000},
    [2] = {label = "صندوق سجائر", item = "cigarette_box", price = 150, itemConvert = 'cigarette', count = 20, max = 500},
   -- [4] = {label = "صندوق ولاعات", item = "lighter_box", price = 300, itemConvert = 'lighter', count = 20, max = 500},
    [3] = {label = "خمر", item = "beer", itemConvert = 'beer', count = 1, max = 500, Storge = false},
    [4] = {label = "خمر فاخر", item = "grand_cru", itemConvert = 'grand_cru', count = 1, max = 500, Storge = false},
    [5] = {label = "عنب", item = "grape", itemConvert = 'grape', count = 1, max = 1000, Storge = false},
    [6] = {label = "عصير عنب", item = "grape_juice", itemConvert = 'grape_juice', count = 1, max = 1000, Storge = false},
  },
  ['pharmacie'] = { -- 3 صيدليات
    [1] = {label = "صندوق دواء زانكس", item = "xanax_box", price = 3000, itemConvert = 'xanax', count = 25, max = 500},
    [2] = {label = "صندوق ضمادات جروح", item = "bandage_box", price = 2800, itemConvert = 'bandage', count = 15, max = 500},
    [3] = {label = "صندوق إسعافات أولية", item = "medikit_box", price = 15000, itemConvert = 'medikit', count = 15, max = 1000},
  },
  ['rts'] = { -- 3 مطاعم
    [1] = {label = "صندوق مياه معدنية", item = "waterbox", price = 900, itemConvert = 'water', count = 20, max = 1000},
    [2] = {label = "صندوق برجر", item = "breadbox", price = 150, itemConvert = 'bread', count = 20, max = 1000},
    [3] = {label = "صندوق كولا", item = "cocacolabox", price = 500, itemConvert = 'cocacola', count = 15, max = 2000},
    [4] = {label = "صندوق فطيرة", item = "cupcakebox", price = 700, itemConvert = 'cupcake', count = 25, max = 2000},
    [5] = {label = "أكياس بطاطس", item = "batatobox", price = 900, itemConvert = 'batato', count = 25, max = 2000},
    [6] = {label = "كرتون بيبسي", item = "pepsibox", price = 1200, itemConvert = 'pepsi', count = 16, max = 2000},
    [7] = {label = "كرتون سوشي", item = "coshebox", price = 2000, itemConvert = 'coshe', count = 10, max = 2000},
    [8] = {label = "صندوق برجر وسط", item = "bergrulbox", price = 6000, itemConvert = 'bergrul', count = 15, max = 2000},
    [9] = {label = "صندوق وجبة برجر كبير", item = "bergrkbbox", price = 8000, itemConvert = 'bergrkb', count = 15, max = 2000}, --وقفت اهني
  },
  ['truck'] = { -- 3 مطاعم
    [1] = {label = "صندوق مياه معدنية", item = "waterbox", price = 1000, itemConvert = 'water', count = 20, max = 4000},
    [2] = {label = "صندوق برجر", item = "breadbox", price = 400, itemConvert = 'bread', count = 20, max = 4000},
    [3] = {label = 'صندوق كاشف رادار', item = "speedcamera_detectorbox", price = 35000, itemConvert = 'speedcamera_detector', count = 10, max = 4000},
    [4] = {label = 'صندوق دريل', item = "drill_box", price = 40000, itemConvert = 'drill', count = 4, max = 4000},
    [5] = {label = 'صندوق قناع أكسجين', item = "oxygen_maskbox", price = 800, itemConvert = 'oxygen_mask', count = 10, max = 4000},
    [6] = {label = 'صندوق طعام حيوانات أليفة', item = "croquettes_box", price = 1000, itemConvert = 'croquettes', count = 10, max = 4000},
    [7] =  {label = 'صندوق عدة معادن', item = "minerToolbox", price = 2500, itemConvert = 'm_tool', count = 15, max = 4000},
    [8] = {label = 'صندوق عدة دواجن', item = "slaughtererToolbox", price = 1500, itemConvert = 's_tool', count = 40, max = 4000},
    [9] = {label = 'صندوق عدة غاز', item = "f_toolbox", price = 3500, itemConvert = 'f_tool', count = 50, max = 4000},
    [10] = {label = 'صندوق عدة أخشاب', item = "lumberjackToolbox", price = 1500, itemConvert = 'l_tool', count = 50, max = 4000},
    [11] = {label = 'صندوق عدة أقمشة', item = "tailorToolbox", price = 1500, itemConvert = 't_tool', count = 50, max = 4000},
    [12] = {label = 'صندوق سنارة صيد سمك', item = "fishbaitbox", price = 4000, itemConvert = 'fishingrod', count = 15, max = 4000},
    [13] = {label = 'صندوق طعم سلاحف بحرية', item = "turtlebaitbox", price = 2000, itemConvert = 'turtlebait', count = 10, max = 4000},
    [14] = {label = 'صندوق طعم اسماك', item = "fishbaitbox", price = 2000, itemConvert = 'fishbait', count = 50, max = 4000},
    [15] = {label = 'صندوق لاب توب', item = "laptop_hbox", price = 160000, itemConvert = 'laptop_h', count = 8, max = 1000},
    [16] = {label = 'صندوق راديو', item = "radiobox", price = 4000, itemConvert = 'radio', count = 6, max = 4000},
    [17] = {label = "عدة سمكرة", item = "carokit_box", price = 3500, itemConvert = 'carokit', count = 10, max = 500, Storge = false},
    [18] = {label = 'صندوق عدة تصليح', item = "fixkit", price = 2000, itemConvert = 'fixkit', count = 40, max = 4000},
    [19] = {label = "صندوق سجائر", item = "cigarette_box", price = 150, itemConvert = 'cigarette', count = 20, max = 4000},
    [20] = {label = "صندوق ولاعات", item = "lighter_box", price = 300, itemConvert = 'lighter', count = 20, max = 4000},
    [21] = {label = "صندوق علبة تعبئة طلقات", item = "boxbig", price = 4000, itemConvert = 'clip', count = 35, max = 4000},
    [22] = {label = 'صندوق سترة مضادة للرصاص', item = "bulletproof_box", price = 1500, itemConvert = 'bulletproof', count = 15, max = 4000},
    [23] = {label = 'صندوق عدة سمكرة', item = "carokit_box", price = 1500, itemConvert = 'carotool', count = 15, max = 4000},
  },
  ['weapons'] = { -- 4 محلات اسلحة
    [1] = {label = 'صندوق سترة مضادة للرصاص', item = "bulletproof_box", price = 8000, itemConvert = 'bulletproof', count = 4, max = 200},
    [2] = {label = 'صندوق منظار يدوي', item = "binoculars_box", price = 20000, itemConvert = 'binoculars', count = 2, max = 100},
    [3] = {label = 'عدة تصنيع سلاح', item = "weaponcrafting", price = 160000, itemConvert = 'weaponcrafting', count = 1, instore = false}, -- for crafting
    [4] = {label = 'صندوق مسدس', item = "pbox", price = 20000, itemConvert = 'WEAPON_PISTOL', count = 4, type = 'weapon', info = { price = 15000, xp = 15, lisence = "weapon"}, count = 2, max = 100},
    [5] = {label = 'صندوق كشاف', item = "fbox", price = 8000, itemConvert = 'WEAPON_FLASHLIGHT', type = 'weapon', info = { price = 3000, xp = 1, lisence = "weapon" }, count = 8, max = 100},
    [6] = {label = 'صندوق ساطور', item = "macbox", price = 12000, itemConvert = 'WEAPON_MACHETE', count = 6, type = 'weapon', info = { price = 5000, xp = 5 , lisence = "weapon" }, black = true, max = 1},
    [7] = {label = 'صندوق سكين', item = "swibox", price = 6000, itemConvert = 'WEAPON_SWITCHBLADE', count = 6, type = 'weapon', info = { price = 4000, xp = 5, lisence = "weapon" }, black = true, max = 1},
    [8] = {label = 'صندوق فأس', item = "ffasbox", price = 12000, itemConvert = 'WEAPON_BATTLEAXE', count = 6, type = 'weapon', info = { price = 5000, xp = 5,  lisence = "weapon" }, black = true, max = 1},
    [9] = {label = 'صندوق شوزن', item = 'WEAPON_PUMPSHOTGUN_box', itemConvert = 'WEAPON_PUMPSHOTGUN', count = 2, Storge = false, type = 'weapon', info = { price = 175000, xp = 30, lisence = "weapon"}, black = true, max = 25},
    [10] = {label = 'صندوق يوزي', item = 'uzbox', itemConvert = 'WEAPON_UZI', count = 2, Storge = false, type = 'weapon', info = { price = 150000, xp = 50, lisence = "weapon" }, black = true, max = 25},
    [11] = {label = 'صندوق رشاش مصغر', item = 'compbox', itemConvert = 'WEAPON_compactrifle', count = 2, Storge = false, type = 'weapon', info = { price = 500000, xp = 75, lisence = "weapon"}, black = true, max = 25},
    [12] = {label = 'صندوق رصاص شدقن', item = "shotgun-store", price = 500, itemConvert = 'ammo-shotgun', count = 50, max = 200},
    [13] = {label = 'صندوق رصاص عيار 45', item = "ammo45-store", price = 500, itemConvert = 'ammo-45', count = 50, max = 200},
    [14] = {label = 'صندوق رصاص عيار 50', item = "ammo50-store", price = 500, itemConvert = 'ammo-50', count = 50, max = 200},
    [15] = {label = 'صندوق مسدس 50', item = "degbox", price = 20000, itemConvert = 'WEAPON_PISTOL50', count = 50, type = 'weapon', info = { price = 250000, xp = 30, lisence = "weapon"}, count = 2, max = 100},
    [16] = {label = 'صندوق m4 ', item = 'm4box', itemConvert = 'WEAPON_m4', count = 2, Storge = false, type = 'weapon', info = { price = 5000000, xp = 100, lisence = "weapon"}, black = true, max = 25},
    [17] = {label = "صندوق علبة تعبئة طلقات", item = "boxbig", price = 4000, itemConvert = 'clip', count = 35, max = 4000},

  },
  ['SodaMachine'] = { -- 15 براد
    [1] = {label = "صندوق مياه معدنية", item = "waterbox", price = 1000, itemConvert = 'water', count = 20, max = 1000},
    [3] = {label = "صندوق شوكلاتة", item = "chocolatebox", price = 500, itemConvert = 'chocolate', count =  30, max = 2000},
    [4] = {label = "صندوق كولا", item = "cocacolabox", price = 500, itemConvert = 'cocacola', count = 15, max = 2000},
    [5] = {label = "صندوق فطيرة", item = "cupcakebox", price = 700, itemConvert = 'cupcake', count = 25, max = 2000},
    [6] = {label = "كرتون شيبس", item = "chepsbox", price = 400, itemConvert = 'cheps', count = 25, max = 2000},
  }
}

Config.Storge = {
  [1] = {
    pos = {x = 765.27429199219, y = -3202.6884765625, z = 6.0137372016907 }
  },
  [2] = {
    pos = {x = 765.14129638672, y = -3187.5368652344, z = 6.0254745483398}
  },
  [3] = {
    pos = {x = 819.32800292969, y = -3194.39453125, z = 5.900815486908 }
  },
  [4] = {
    pos = {x = 827.39227294922, y = -3208.3137207031, z = 5.9008197784424}
  },
  [5] = {
    pos = {x = 834.77355957031, y = -3207.8352050781, z = 5.9008164405823}
  },
  [6] = {
    pos = {x = 849.1083984375, y = -3207.359375, z = 5.9007439613342}
  },
  [7] = {
    pos = {x = 854.970703125, y = -3206.9436035156, z = 5.9007487297058}
  },
  [8] = {
    pos = {x = 865.91473388672, y = -3206.6291503906, z = 5.9006609916687}
  },
}

Config.Storge2 = {
  [1] = {
    pos = {x = -127.93429199219, y = -2535.0184765625, z = 6.0037372016907 }
  },
  [2] = {
    pos = {x = -110.000703125, y = -2509.8136035156, z = 4.8507487297058}
  },
  [3] = {
    pos = {x = -106.070703125, y = -2503.7936035156, z = 4.8507487297058}
  },
  [4] = {
    pos = {x = -122.830703125, y = -2491.9436035156, z = 6.0107487297058}
  },
  [5] = {
    pos = {x = -126.980703125, y = -2497.6536035156, z = 6.0107487297058}
  },
  [6] = {
    pos = {x = -135.220703125, y = -2509.7136035156, z = 6.107487297058}
  },
  [7] = {
    pos = {x = -138.540703125, y = -2514.6636035156, z = 6.1007487297058}
  },
  [8] = {
    pos = {x = -144.90703125, y = -2523.2236035156, z = 6.0007487297058}
  },
}

Config.Zones = {
  ShopCenter = {
    Pos   = {x = -1080.9113769531,   y = -247.77198791504,  z = 37.763282775879 - 1.0, number = 'center'},
  },

  crafting = {
    Pos   = {x = 1388.790, y = 3605.022, z = 38.941 - 1.0, number = 'crafting', craft = true},
  },

  --BAR
  [1] = {Type = 'bar', Pos = { x = -560.1671, y = 286.6096, z = 82.17639 - 1.0, number = 1}, Object = { x = -561.907, y = 288.9489, z = 82.17641 - 1.0, h = 173.601}},
  [101] = {Type = 'bar', Pos = { x = -562.0709, y = 287.4278, z = 82.17651 - 1.0, number = 101 , red = true}},

 
  [2] = {Type = 'bar', Pos = { x = 4515.7466, y = -4495.8877, z = 4.2997 - 1.0, number = 2}, Object = { x = 4519.5254, y = -4496.8447, z = 4.2996, - 1.0, h = 4.86}},
  [102] = {Type = 'bar', Pos = { x = 4518.8545, y = -4494.3984, z = 4.2997 - 1.0, number = 102 , red = true}},
  
  [3] = {Type = 'bar', Pos = { x = -1393.7664794922, y = -606.80535888672, z = 30.319547653198 - 1.0, number = 3}, Object = { x = -1382.2415771484, y = -632.43048095703, z = 30.819561004639 - 1.0, h = 222.47}},
  [103] = {Type = 'bar', Pos = { x = -1383.6768798828, y = -629.28344726562, z = 30.819566726685 - 1.0, number = 103 , red = true}},
  
  
  --WEAPONS
  [4] = {Type = 'weapons', Pos = { x = 21.3957, y = -1106.9948, z = 29.7970 - 1.0, number = 4}, Object = { x = 7.5172, y = -1104.7906, z =29.7970 - 1.0, h = 93.14}},
  [104] = {Type = 'weapons', Pos = { x = 12.6904, y = -1103.3611, z = 29.7970 - 1.0, number = 104 , red = true}},

  [5] = {Type = 'weapons', Pos = { x = 1693.6502685547, y = 3759.7641601562, z = 34.705310821533 - 1.0, number = 5}, Object = { x = 1699.5583496094, y = 3755.8117675781, z = 34.705368041992 - 1.0, h = 227.04}},
  [105] = {Type = 'weapons', Pos = { x = 1697.7174072266, y = 3758.1162109375, z = 34.705375671387 - 1.0, number = 105 , red = true}},
  
  [6] = {Type = 'weapons', Pos = { x = -330.28884887695, y = 6083.5375976562, z = 31.454761505127 - 1.0, number = 6}, Object = { x = -324.5280456543, y = 6079.5380859375, z = 31.454759597778 - 1.0, h = 220.97}},
  [106] = {Type = 'weapons', Pos = { x = -326.65054321289, y = 6082.021484375, z = 31.45477104187 - 1.0, number = 106 , red = true}},

  --PHARMACIE
  [7] = {Type = 'pharmacie', Pos = { x = 317.83837890625, y = -1076.7145996094, z = 29.478578567505 - 1.0, number = 7}, Object = { x = 326.73440551758, y = -1078.0108642578, z = 29.481616973877 - 1.0, h = 184.52}},
  [107] = {Type = 'pharmacie', Pos = { x = 326.19342041016, y = -1075.9624023438, z = 29.489372253418 - 1.0, number = 107 , red = true}},

  [8] = {Type = 'pharmacie', Pos = { x = -172.90054321289, y = 6385.78515625, z = 31.495471954346 - 1.0, number = 8}, Object = { x = -173.76063537598, y = 6389.4594726562, z = 31.49561882019 - 1.0, h = 229.28}},
  [108] = {Type = 'pharmacie', Pos = { x = -176.52363586426, y = 6391.5620117188, z = 31.495742797852 - 1.0, number = 108 , red = true}},
  --rts

  --SODAMACHINE
  [9] = {Type = 'SodaMachine', Pos = { x = 408.91928100586, y = -1613.4937744141, z = 29.291561126709 - 1.0, number = 9}},
  [10] = {Type = 'SodaMachine', Pos = { x = 1673.8820800781, y = 3834.626953125, z = 34.898639678955 - 1.0, number = 10}},
  [11] = {Type = 'SodaMachine', Pos = { x = -346.64266967773, y = 6072.1962890625, z = 31.46435546875 - 1.0, number = 11}},
  [12] = {Type = 'SodaMachine', Pos = { x = -563.73876953125, y = 5383.263671875, z = 69.544052124023 - 1.0, number = 12}},
  [13] = {Type = 'SodaMachine', Pos = { x = 815.1201171875, y = -2972.072265625, z = 6.0206570625305 - 1.0, number = 13}},
  [14] = {Type = 'SodaMachine', Pos = { x = 717.84405517578, y = -2553.4470214844, z = 19.814624786377 - 1.0, number = 14}},
  [15] = {Type = 'SodaMachine', Pos = { x = 35.372180938721, y = -2537.4694824219, z = 6.1557121276855 - 1.0, number = 15}},
  [16] = {Type = 'SodaMachine', Pos = { x = 433.52359008789, y = -657.95819091797, z = 28.783494949341 - 1.0, number = 16}},
  [17] = {Type = 'SodaMachine', Pos = { x = 1147.1302490234, y = -1521.2679443359, z = 34.843738555908 - 1.0, number = 17}},
  [18] = {Type = 'SodaMachine', Pos = { x = 1847.9249267578, y = 3677.1435546875, z = 34.272296905518 - 1.0, number = 18}},
  [19] = {Type = 'SodaMachine', Pos = { x = -235.73170471191, y = 6315.9340820312, z = 31.481941223145 - 1.0, number = 19}},
  [20] = {Type = 'SodaMachine', Pos = { x = 417.98495483398, y = -985.43151855469, z = 29.408435821533 - 1.0, number = 20}},
  [21] = {Type = 'SodaMachine', Pos = { x = -444.69448852539, y = 6024.0493164062, z = 31.490100860596 - 1.0, number = 21}},
  [22] = {Type = 'SodaMachine', Pos = { x = 1846.9528808594, y = 2587.4880371094, z = 45.672374725342 - 1.0, number = 22}},

  --Market
  -- 1961.1869, 3740.5640, 32.3438, 111.4337
  [23] = {Type = 'pharmacie', Pos = { x = -172.90054321289, y = 6385.78515625, z = 31.495471954346 - 1.0, number = 23}, Object = { x = -173.76063537598, y = 6389.4594726562, z = 31.49561882019 - 1.0, h = 229.28}},
  [123] = {Type = 'pharmacie', Pos = { x = -176.52363586426, y = 6391.5620117188, z = 31.495742797852 - 1.0, number = 123 , red = true}},

  [24] = {Type = 'market', Pos = { x = -303.798, y = 6099.431, z = 31.799 - 1.0, number = 24}, Object = {x = -302.579, y = 6113.099, z = 31.790 - 1.0, h = 42.69}},
  [124] = {Type = 'market', Pos = {x = -310.270, y = 6106.050, z = 31.790 - 1.0, number = 124 , red = true}},


  --vector4(294.4503, -1256.11, 29.40766, 356.6542)

  [25] = {Type = 'market', Pos = {x = 1961.4779052734, y = 3740.7106933594, z = 32.343734741211 - 1.0, number = 25}, Object = {x = 1960.7133789063, y = 3748.8032226563, z = 32.343734741211 - 1.0, h = 283.32}},
  [125] = {Type = 'market', Pos = {x = 1957.4331054688, y = 3746.9916992188, z = 32.343734741211 - 1.0, number = 125 , red = true}},
--vector4(294.4503, -1256.11, 29.40766, 356.6542)
  [26] = {Type = 'market', Pos = {x = 294.4503, y = -1256.11, z = 29.40766 - 1.0, number = 26}, Object = {x = 299.749, y = -1260.636, z = 29.40766 - 1.0, h = 4.451039}},
  [126] = {Type = 'market', Pos = {x = 299.9402, y = -1257.579, z = 29.40766 - 1.0, number = 126 , red = true}},
--vector4(299.749, -1260.636, 29.40766, 4.451039)
  [27] = {Type = 'market', Pos = { x = 161.48846435547, y = 6640.427734375, z = 31.710620880127 - 1.0, number = 27}, Object = {x = 169.06771850586, y = 6643.439453125, z = 31.710647583008 - 1.0, h = 226.37}},
  [127] = {Type = 'market', Pos = { x = 167.04598999023, y = 6645.6953125, z = 31.710622787476 - 1.0, number = 127 , red = true}},

  [33] = {Type = 'market', Pos = { x = 1136.074, y = -981.7689, z = 46.4158 - 1.0, number = 33}, Object = {x = 1126.737, y = -979.3583, z = 45.57568 - 1.0, h = 188.3929}},
  [133] = {Type = 'market', Pos = { x = 1126.832, y = -980.5998, z = 45.41568 - 1.0, number = 133 , red = true}},

  [28] = {Type = 'market', Pos = { x = -48.471775054932, y = -1757.2221679688, z = 29.421014785767 - 1.0, number = 28}, Object = {x = -42.472969055176, y = -1749.3958740234, z = 29.421016693115 - 1.0, h = 328.88}},
  [128] = {Type = 'market', Pos = { x = -43.516532897949, y = -1750.6414794922, z = 29.421020507813 - 1.0, number = 128 , red = true}},
  
  [30] = {Type = 'market', Pos = { x = 268.9791, y = -980.262, z = 29.36961 - 1.0, number = 30}, Object = { x = 273.9636, y = -985.7688, z = 29.36962 - 1.0, h = 161.5698}},
  [130] = {Type = 'market', Pos = { x = 274.8636, y = -984.0274, z = 29.36962 - 1.0, number = 130 , red = true}},

  [37] = {Type = 'market', Pos = { x = 1166.225, y = 2708.824, z = 38.157 - 1.0, number = 37}, Object = { x = 1165.274, y = 2714.057, z = 38.157 - 1.0, h = 115.3417}},
  [137] = {Type = 'market', Pos = { x = 1167.621, y = 2714.323, z = 38.157 - 1.0, number = 137 , red = true}},

  [38] = {Type = 'market', Pos = { x = 1211.377, y = -1382.597, z = 35.40779 - 1.0, number = 38}, Object = { x = 1212.695, y = -1380.471, z = 35.40779 - 1.0, h = 95.81954}},
  [138] = {Type = 'market', Pos = { x = 1210.557, y = -1380.494, z = 35.40779 - 1.0, number = 138 , red = true}},

  [39] = {Type = 'market', Pos = { x = 2678.940, y = 3280.736, z = 55.241 - 1.0, number = 39}, Object = { x = 2672.106, y = 3283.934, z = 55.241 - 1.0, h = 95.81954}},
  [139] = {Type = 'market', Pos = { x = 2672.106, y = 3283.934, z = 55.241 - 1.0, number = 139 , red = true}},
--vector3(2672.106, 3283.934, 55.241)
--vector3(2678.940, 3280.736, 55.241)
[40] = {Type = 'market', Pos = { x = 26.06522, y = -1347.43, z = 29.497 - 1.0, number = 40}, Object = { x = 29.62063, y = -1340.10, z = 29.497 - 1.0, h = 95.81954}},
[140] = {Type = 'market', Pos = { x = 25.59509, y = -1339.75, z = 29.497 - 1.0, number = 140 , red = true}},

[41] = {Type = 'market', Pos = { x = 1162.931, y = -324.200, z = 69.205 - 1.0, number = 41}, Object = { x = 1160.949, y = -313.082, z = 69.205 - 1.0, h = 95.81954}},
[141] = {Type = 'market', Pos = { x = 1160.957, y = -316.205, z = 69.205 - 1.0, number = 141 , red = true}},
[42] = {Type = 'market', Pos = { x = -345.155, y = -1485.56, z = 30.788 - 1.0, number = 42}, Object = { x = -352.202, y = -1481.33, z = 30.788 - 1.0, h = 95.81954}},
[142] = {Type = 'market', Pos = { x = -352.362, y = -1486.56, z = 30.788 - 1.0, number = 142 , red = true}},
[43] = {Type = 'market', Pos = { x = -707.818, y = -914.606, z = 19.215 - 1.0, number = 43}, Object = { x = -708.168, y = -903.423, z = 19.215 - 1.0, h = 95.81954}},
[143] = {Type = 'market', Pos = { x = -708.946, y = -906.240, z = 19.215 - 1.0, number = 143 , red = true}},

[44] = {Type = 'market', Pos = { x = -1423.48, y = -269.934, z = 46.278 - 1.0, number = 44}, Object = { x = -1415.69, y = -262.403, z = 46.379 - 1.0, h = 95.81954}},
[144] = {Type = 'market', Pos = {x = -1417.99, y = -263.284, z = 46.379 - 1.0, number = 144 , red = true}},

[45] = {Type = 'market', Pos = { x = -1487.14, y = -379.768, z = 40.163 - 1.0, number = 45}, Object = { x = -1478.91, y = -375.315, z = 39.163 - 1.0, h = 95.81954}},
[145] = {Type = 'market', Pos = {x = -1480.70, y = -373.750, z = 39.163 - 1.0, number = 145 , red = true}},

[46] = {Type = 'market', Pos = { x = -2070.55, y = -324.589, z = 13.307 - 1.0, number = 46}, Object = { x = -2063.37, y = -330.223, z = 13.307 - 1.0, h = 95.81954}},
[146] = {Type = 'market', Pos = {x = -2062.76, y = -324.229, z = 13.307 - 1.0, number = 146 , red = true}},

[47] = {Type = 'market', Pos = { x = 374.3197, y = 326.0515, z = 103.56 - 1.0, number = 47}, Object = { x = 379.7462, y = 332.0254, z = 103.56 - 1.0, h = 95.81954}},
[147] = {Type = 'market', Pos = {x = 375.5229, y = 333.0688, z = 103.56 - 1.0, number = 147 , red = true}},

[48] = {Type = 'market', Pos = { x = 1392.289, y = 3604.406, z = 34.980 - 1.0, number = 48}, Object = { x = 1394.051, y = 3609.096, z = 34.980 - 1.0, h = 95.81954}},
[148] = {Type = 'market', Pos = {x = 1390.800, y = 3607.957, z = 34.980 - 1.0, number = 148 , red = true}},

[49] = {Type = 'market', Pos = { x = 1729.500, y = 6414.525, z = 35.037 - 1.0, number = 49}, Object = { x = 1736.816, y = 6419.077, z = 35.037 - 1.0, h = 95.81954}},
[149] = {Type = 'market', Pos = {x = 1732.053, y = 6421.510, z = 35.037 - 1.0, number = 149 , red = true}},

[50] = {Type = 'market', Pos = { x = -3039.26, y = 585.9508, z = 7.9089 - 1.0, number = 50}, Object = { x = -3047.78, y = 588.0042, z = 7.9089 - 1.0, h = 95.81954}},
[150] = {Type = 'market', Pos = {x = -3046.33, y = 582.9376, z = 7.9089 - 1.0, number = 150 , red = true}},

[51] = {Type = 'market', Pos = { x = -2968.07, y = 390.3972, z = 15.043 - 1.0, number = 51}, Object = { x = -2963.30, y = 391.9166, z = 15.043 - 1.0, h = 95.81954}},
[151] = {Type = 'market', Pos = {x = -2963.25, y = 387.9186, z = 15.043 - 1.0, number = 151 , red = true}},

--vector3(26.06522, -1347.43, 29.497)

  --vector4(1126.737, -979.3583, 45.57568, 188.3929)
  --vector4(1136.074, -981.7689, 46.4158, 101.3546)

  --vector4(1126.832, -980.5998, 45.41568, 6.942893)
  

  [31] = {Type = 'rts', Pos = { x = -582.914, y = -1060.36, z = 22.344 - 1.0, number = 31}, Object = { x = -597.611, y = -1052.64, z = 22.344 - 1.0, h = 196.71}},
  [131] = {Type = 'rts', Pos = { x = -596.522, y = -1049.85, z = 22.344 - 1.0, number = 131 , red = true}},

  --[32] = {Type = 'rts', Pos = { x = -169.7446, y = 295.1643, z = 93.7674 - 1.0, number = 32}, Object = { x = -178.233, y = 301.7864, z = 100.9274 - 1.0, h = 129.5}},
  --[132] = {Type = 'rts', Pos = { x = -175.3446, y = 304.1343, z = 100.9274 - 1.0, number = 132 , red = true}},
  
  --[29] = {Type = 'rts', Pos = { x = 88.17446, y = 286.2443, z = 110.2174 - 1.0, number = 29}, Object = { x = 85.54213, y = 292.8164, z = 110.2074 - 1.0, h = 157.88}},
  --[129] = {Type = 'rts', Pos = { x = 86.18446, y = 294.9843, z = 110.2074 - 1.0, number = 129 , red = true}},

  --vector4(-562.0709, 287.4278, 82.17651, 100.9085)


  --vector4(-561.907, 288.9489, 82.17641, 173.601)

}