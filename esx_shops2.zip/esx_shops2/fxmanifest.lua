

fx_version 'adamant'

game 'gta5'

shared_script '@esx_misc3/init.lua'

ui_page('html/index.html') 

files({
  'html/font/vibes.ttf',
  'html/font/RB-Bold.ttf',
  'html/img/*.png',
  'html/index.html',
  'html/script.js',
  'html/style.css',
})

client_scripts {
  '@es_extended/locale.lua',
  'locales/*.lua',
  'client/cl_config.lua',
  'client/main.lua',
}

server_scripts {
  '@oxmysql/lib/MySQL.lua',
  'server/config.lua',
  'server/main.lua',
}


shared_script '@es_extended/imports.lua'