Framework = nil

-- Framework Detection Function
local function GetFramework()
    if Config.Framework == "ESX" then
        local ESX = nil
        TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)
        
        -- Wait for ESX to load
        while not ESX do
            Citizen.Wait(10)
        end
        
        return ESX
    elseif Config.Framework == "QBCore" then
        return exports["qb-core"]:GetCoreObject()
    elseif Config.Framework == "OLDQBCore" then
        local QBCore = nil
        TriggerEvent("QBCore:GetObject", function(obj) QBCore = obj end)
        
        -- Wait for QBCore to load
        while not QBCore do
            Citizen.Wait(10)
        end
        
        return QBCore
    end
    
    return nil
end

-- Initialize Framework
Framework = GetFramework()

-- Modern Notification System
local function SendNotification(source, message, type, duration)
    if Config.NotificationSystem == "qb" then
        TriggerClientEvent('QBCore:Notify', source, message, type, duration or 5000)
    elseif Config.NotificationSystem == "esx" then
        TriggerClientEvent('esx:showNotification', source, message)
    elseif Config.NotificationSystem == "ox" then
        TriggerClientEvent('ox_lib:notify', source, {
            title = 'Shop',
            description = message,
            type = type,
            duration = duration or 5000
        })
    else
        -- Custom notification system
        TriggerClientEvent('es-shop:notification', source, message, type, duration)
    end
end

-- Modern Item System
local function GiveItem(Player, itemModel, quantity, isESX)
    local success = false
    
    if isESX then
        -- ESX Item System
        if itemModel:find("WEAPON_") then
            -- It's a weapon
            Player.addWeapon(itemModel, 0)
            success = true
        else
            -- It's a regular item
            Player.addInventoryItem(itemModel, quantity)
            success = true
        end
    else
        -- QBCore Item System
        if itemModel:find("WEAPON_") then
            -- It's a weapon
            Player.Functions.AddItem(itemModel, 1, false, nil)
            success = true
        else
            -- It's a regular item
            Player.Functions.AddItem(itemModel, quantity, false, nil)
            success = true
        end
        
        -- Trigger inventory update for QBCore
        if success then
            local itemData = Player.Functions.GetItemByName(itemModel)
            if itemData then
                TriggerClientEvent('inventory:client:ItemBox', Player.PlayerData.source, itemData, "add")
            end
        end
    end
    
    return success
end

-- Remove Player Money with Payment Method
local function RemovePlayerMoneyWithMethod(Player, amount, paymentMethod, isESX)
    local success = false
    
    if isESX then
        if paymentMethod == "bank" then
            local bankAccount = Player.getAccount("bank")
            if bankAccount.money >= amount then
                Player.removeAccountMoney("bank", amount)
                success = true
            end
        else -- cash
            if Player.getMoney() >= amount then
                Player.removeMoney(amount)
                success = true
            end
        end
    else
        if paymentMethod == "bank" then
            if Player.Functions.RemoveMoney("bank", amount) then
                success = true
            end
        else -- cash
            if Player.Functions.RemoveMoney("cash", amount) then
                success = true
            end
        end
    end
    
    return success
end

-- Get Player Money with Payment Method
local function GetPlayerMoneyWithMethod(Player, paymentMethod, isESX)
    if isESX then
        if paymentMethod == "bank" then
            return Player.getAccount("bank").money
        else
            return Player.getMoney()
        end
    else
        if paymentMethod == "bank" then
            return Player.PlayerData.money["bank"]
        else
            return Player.PlayerData.money["cash"]
        end
    end
end

-- Find Item in Config
local function FindItemInConfig(itemId)
    for shopKey, shopData in pairs(Config.Items) do
        if shopData.Items then
            for _, item in pairs(shopData.Items) do
                if item.id == itemId then
                    return item
                end
            end
        end
    end
    return nil
end

-- Wait for Framework to be ready
Citizen.CreateThread(function()
    while not Framework do
        Citizen.Wait(100)
    end
    
    print("[ES-SHOP] Framework loaded: " .. Config.Framework)
    
    -- Framework Detection and Initialization
    if Config.Framework == "ESX" then
        -- Get User Money Callback
        Framework.RegisterServerCallback("es-shop:getUserMoney", function(source, cb)
            local xPlayer = Framework.GetPlayerFromId(source)
            if xPlayer then
                local cash, bank = GetPlayerMoneyWithMethod(xPlayer, "cash", true), GetPlayerMoneyWithMethod(xPlayer, "bank", true)
                cb(cash, bank)
            else
                cb(0, 0)
            end
        end)

        -- Buy Item Callback
        Framework.RegisterServerCallback("es-shop:buyItem", function(source, cb, data)
            print("[ES-SHOP] Buy item callback triggered", json.encode(data))
            
            local xPlayer = Framework.GetPlayerFromId(source)
            if not xPlayer then
                print("[ES-SHOP] Player not found")
                cb(false, "Player not found")
                return
            end

            local item = FindItemInConfig(data.id)
            if not item then
                print("[ES-SHOP] Item not found:", data.id)
                cb(false, "Item not found")
                SendNotification(source, "Item not found in shop!", "error")
                return
            end

            local quantity = data.quantity or 1
            local totalPrice = item.price * quantity

            -- Check money
            local cash, bank = GetPlayerMoneyWithMethod(xPlayer, "cash", true), GetPlayerMoneyWithMethod(xPlayer, "bank", true)
            if cash < totalPrice then
                print("[ES-SHOP] Not enough money:", cash, totalPrice)
                cb(false, "Not enough money")
                SendNotification(source, "Not enough money! Need $" .. totalPrice, "error")
                return
            end

            -- Check level requirement
            if Config.ShopFeatures.EnableLevelRestrictions and item.level then
                local playerLevel = xPlayer.get('level') or 1
                if playerLevel < item.level then
                    cb(false, "Level requirement not met")
                    SendNotification(source, "Level " .. item.level .. " required!", "error")
                    return
                end
            end

            -- Process purchase
            if RemovePlayerMoneyWithMethod(xPlayer, totalPrice, "cash", true) then
                local success = GiveItem(xPlayer, item.model, quantity, true)
                
                if success then
                    local newCash, newBank = GetPlayerMoneyWithMethod(xPlayer, "cash", true), GetPlayerMoneyWithMethod(xPlayer, "bank", true)
                    print("[ES-SHOP] Purchase successful:", item.name, quantity, totalPrice)
                    
                    cb(true, "Purchase successful", {
                        cash = newCash,
                        bank = newBank,
                        item = item,
                        quantity = quantity
                    })
                    
                    SendNotification(source, "Purchased " .. quantity .. "x " .. item.name .. " for $" .. totalPrice, "success")
                    
                    -- Log the purchase
                    print(string.format("[ES-SHOP] Player %s purchased %dx %s for $%d", 
                        xPlayer.identifier, quantity, item.name, totalPrice))
                else
                    -- Refund money if item giving failed
                    xPlayer.addMoney(totalPrice)
                    cb(false, "Failed to give item")
                    SendNotification(source, "Failed to give item! Money refunded.", "error")
                end
            else
                cb(false, "Payment failed")
                SendNotification(source, "Payment failed!", "error")
            end
        end)

        -- Buy Multiple Items (Cart) Callback
        Framework.RegisterServerCallback("es-shop:buyCart", function(source, cb, cartData)
            print("[ES-SHOP] Buy cart callback triggered", json.encode(cartData))
            
            local xPlayer = Framework.GetPlayerFromId(source)
            if not xPlayer then
                cb(false, "Player not found")
                return
            end

            -- Extract payment method and items
            local paymentMethod = cartData.paymentMethod or "cash"
            local items = cartData.items or cartData
            
            print("[ES-SHOP] Payment method:", paymentMethod)
            print("[ES-SHOP] Items to process:", json.encode(items))
            
            local totalPrice = 0
            local validItems = {}

            -- Validate all items and calculate total price
            for _, cartItem in pairs(items) do
                print("[ES-SHOP] Processing cart item:", json.encode(cartItem))
                local item = FindItemInConfig(cartItem.id)
                if item then
                    print("[ES-SHOP] Item found:", item.name, "Price:", item.price, "Quantity:", cartItem.quantity)
                    table.insert(validItems, {
                        item = item,
                        quantity = cartItem.quantity
                    })
                    totalPrice = totalPrice + (item.price * cartItem.quantity)
                else
                    print("[ES-SHOP] Item not found with ID:", cartItem.id)
                end
            end

            print("[ES-SHOP] Valid items count:", #validItems, "Total price:", totalPrice)

            if #validItems == 0 then
                cb(false, "No valid items in cart")
                SendNotification(source, "No valid items in cart!", "error")
                return
            end

            -- Check money based on payment method
            local currentBalance = GetPlayerMoneyWithMethod(xPlayer, paymentMethod, true)
            if currentBalance < totalPrice then
                cb(false, "Not enough money")
                SendNotification(source, "Not enough " .. paymentMethod .. "! Need $" .. totalPrice, "error")
                return
            end

            -- Process purchase with selected payment method
            if RemovePlayerMoneyWithMethod(xPlayer, totalPrice, paymentMethod, true) then
                local successCount = 0
                local failedItems = {}

                for _, validItem in pairs(validItems) do
                    local success = GiveItem(xPlayer, validItem.item.model, validItem.quantity, true)
                    if success then
                        successCount = successCount + 1
                    else
                        table.insert(failedItems, validItem.item.name)
                    end
                end

                local newCash, newBank = GetPlayerMoneyWithMethod(xPlayer, "cash", true), GetPlayerMoneyWithMethod(xPlayer, "bank", true)
                cb(true, "Purchase completed", {
                    cash = newCash,
                    bank = newBank,
                    successCount = successCount,
                    failedItems = failedItems
                })

                if #failedItems > 0 then
                    SendNotification(source, "Some items failed to be given: " .. table.concat(failedItems, ", "), "error")
                else
                    SendNotification(source, "Successfully purchased " .. successCount .. " items for $" .. totalPrice .. " via " .. paymentMethod:upper(), "success")
                end
            else
                cb(false, "Payment failed")
                SendNotification(source, "Payment failed!", "error")
            end
        end)

    elseif Config.Framework == "QBCore" or Config.Framework == "OLDQBCore" then
        -- Get User Money Callback
        Framework.Functions.CreateCallback("es-shop:getUserMoney", function(source, cb)
            local Player = Framework.Functions.GetPlayer(source)
            if Player then
                local cash, bank = GetPlayerMoneyWithMethod(Player, "cash", false), GetPlayerMoneyWithMethod(Player, "bank", false)
                cb(cash, bank)
            else
                cb(0, 0)
            end
        end)

        -- Buy Item Callback
        Framework.Functions.CreateCallback("es-shop:buyItem", function(source, cb, data)
            print("[ES-SHOP] Buy item callback triggered", json.encode(data))
            
            local Player = Framework.Functions.GetPlayer(source)
            if not Player then
                print("[ES-SHOP] Player not found")
                cb(false, "Player not found")
                return
            end

            local item = FindItemInConfig(data.id)
            if not item then
                print("[ES-SHOP] Item not found:", data.id)
                cb(false, "Item not found")
                SendNotification(source, "Item not found in shop!", "error")
                return
            end

            local quantity = data.quantity or 1
            local totalPrice = item.price * quantity

            -- Check money
            local cash, bank = GetPlayerMoneyWithMethod(Player, "cash", false), GetPlayerMoneyWithMethod(Player, "bank", false)
            if cash < totalPrice then
                print("[ES-SHOP] Not enough money:", cash, totalPrice)
                cb(false, "Not enough money")
                SendNotification(source, "Not enough money! Need $" .. totalPrice, "error")
                return
            end

            -- Check level requirement
            if Config.ShopFeatures.EnableLevelRestrictions and item.level then
                local playerLevel = Player.PlayerData.metadata.level or 1
                if playerLevel < item.level then
                    cb(false, "Level requirement not met")
                    SendNotification(source, "Level " .. item.level .. " required!", "error")
                    return
                end
            end

            -- Process purchase
            if RemovePlayerMoneyWithMethod(Player, totalPrice, "cash", false) then
                local success = GiveItem(Player, item.model, quantity, false)
                
                if success then
                    local newCash, newBank = GetPlayerMoneyWithMethod(Player, "cash", false), GetPlayerMoneyWithMethod(Player, "bank", false)
                    print("[ES-SHOP] Purchase successful:", item.name, quantity, totalPrice)
                    
                    cb(true, "Purchase successful", {
                        cash = newCash,
                        bank = newBank,
                        item = item,
                        quantity = quantity
                    })
                    
                    SendNotification(source, "Purchased " .. quantity .. "x " .. item.name .. " for $" .. totalPrice, "success")
                    
                    -- Log the purchase
                    print(string.format("[ES-SHOP] Player %s purchased %dx %s for $%d", 
                        Player.PlayerData.citizenid, quantity, item.name, totalPrice))
                else
                    -- Refund money if item giving failed
                    Player.Functions.AddMoney("cash", totalPrice)
                    cb(false, "Failed to give item")
                    SendNotification(source, "Failed to give item! Money refunded.", "error")
                end
            else
                cb(false, "Payment failed")
                SendNotification(source, "Payment failed!", "error")
            end
        end)

        -- Buy Multiple Items (Cart) Callback
        Framework.Functions.CreateCallback("es-shop:buyCart", function(source, cb, cartData)
            print("[ES-SHOP] Buy cart callback triggered", json.encode(cartData))
            
            local Player = Framework.Functions.GetPlayer(source)
            if not Player then
                cb(false, "Player not found")
                return
            end

            -- Extract payment method and items
            local paymentMethod = cartData.paymentMethod or "cash"
            local items = cartData.items or cartData
            
            print("[ES-SHOP] Payment method:", paymentMethod)
            print("[ES-SHOP] Items to process:", json.encode(items))
            
            local totalPrice = 0
            local validItems = {}

            -- Validate all items and calculate total price
            for _, cartItem in pairs(items) do
                print("[ES-SHOP] Processing cart item:", json.encode(cartItem))
                local item = FindItemInConfig(cartItem.id)
                if item then
                    print("[ES-SHOP] Item found:", item.name, "Price:", item.price, "Quantity:", cartItem.quantity)
                    table.insert(validItems, {
                        item = item,
                        quantity = cartItem.quantity
                    })
                    totalPrice = totalPrice + (item.price * cartItem.quantity)
                else
                    print("[ES-SHOP] Item not found with ID:", cartItem.id)
                end
            end

            print("[ES-SHOP] Valid items count:", #validItems, "Total price:", totalPrice)

            if #validItems == 0 then
                cb(false, "No valid items in cart")
                SendNotification(source, "No valid items in cart!", "error")
                return
            end

            -- Check money based on payment method
            local currentBalance = GetPlayerMoneyWithMethod(Player, paymentMethod, false)
            if currentBalance < totalPrice then
                cb(false, "Not enough money")
                SendNotification(source, "Not enough " .. paymentMethod .. "! Need $" .. totalPrice, "error")
                return
            end

            -- Process purchase with selected payment method
            if RemovePlayerMoneyWithMethod(Player, totalPrice, paymentMethod, false) then
                local successCount = 0
                local failedItems = {}

                for _, validItem in pairs(validItems) do
                    local success = GiveItem(Player, validItem.item.model, validItem.quantity, false)
                    if success then
                        successCount = successCount + 1
                    else
                        table.insert(failedItems, validItem.item.name)
                    end
                end

                local newCash, newBank = GetPlayerMoneyWithMethod(Player, "cash", false), GetPlayerMoneyWithMethod(Player, "bank", false)
                cb(true, "Purchase completed", {
                    cash = newCash,
                    bank = newBank,
                    successCount = successCount,
                    failedItems = failedItems
                })

                if #failedItems > 0 then
                    SendNotification(source, "Some items failed to be given: " .. table.concat(failedItems, ", "), "error")
                else
                    SendNotification(source, "Successfully purchased " .. successCount .. " items for $" .. totalPrice .. " via " .. paymentMethod:upper(), "success")
                end
            else
                cb(false, "Payment failed")
                SendNotification(source, "Payment failed!", "error")
            end
        end)
    end

    -- Legacy support for old "control" callback
    if Config.Framework == "ESX" then
        Framework.RegisterServerCallback("control", function(source, cb, data)
            -- Convert old format to new format
            local newData = {
                id = data.id or data.item_id,
                quantity = data.quantity or 1
            }
            
            Framework.TriggerServerCallback("es-shop:buyItem", source, function(success, message, result)
                if success then
                    cb(true, result.cash, result.bank)
                else
                    cb(false, 0, 0)
                end
            end, newData)
        end)
    elseif Config.Framework == "QBCore" or Config.Framework == "OLDQBCore" then
        Framework.Functions.CreateCallback("control", function(source, cb, data)
            -- Convert old format to new format
            local newData = {
                id = data.id or data.item_id,
                quantity = data.quantity or 1
            }
            
            Framework.Functions.TriggerCallback("es-shop:buyItem", source, function(success, message, result)
                if success then
                    cb(true, result.cash, result.bank)
                else
                    cb(false, 0, 0)
                end
            end, newData)
        end)
    end
end)
