Config = {
    -- Framework Configuration
    Framework = "QBCore", -- "QBCore", "OLDQBCore", or "ESX"
    
    -- Notification System
    NotificationSystem = "qb", -- "qb", "esx", "ox", "custom"
    
    -- Buy Settings
    BuySettings = {
        UseProgressBar = true,
        ProgressBarDuration = 1500, -- ms
        RemoveItemAfterPurchase = false, -- Mağazadan item'i kaldır
        ShowPurchaseEffects = true, -- Satın alma efektleri
        MaxQuantityPerPurchase = 10, -- Tek seferde alınabilecek max miktar
    },
    
    -- Modern Shop Features
    ShopFeatures = {
        EnableCart = true,
        EnableSearch = true,
        EnableLevelRestrictions = true,
        EnableRaritySystem = true,
        EnableNotifications = true,
    },
    
    Categories = {
        ["shop1"] = {
            "All", "Handguns", "Submachine Guns", "Assault Rifles", "Shotguns", "Sniper Rifles", "Ammunition", "Weapon Mods"
        },
        ["shop2"] = {
            "All", "Healthy Food", "Beverages", "Medicine"
        },
        ["shop3"] = {
            "All", "Surveillance"
        },
        ["shop4"] = {
            "All", "Tools", "Emergency"
        }
    },
    Items = {
        ["shop1"] = {
            Items = {
                -- HANDGUNS
                {
                    id = 1, name = "Pistol", type = "Handgun", rarity = "common", category = "Handguns",
                    model = "WEAPON_PISTOL", price = 2500, sellPrice = 750, level = 1,
                    icon = "fas fa-gun", image = "assets/img/item/weapon_pistol.png",
                    stats = { damage = 26, accuracy = 50, range = 30, fireRate = 0.4 },
                    attributes = {
                        { name = "Damage", value = "26" },
                        { name = "Accuracy", value = "50%" },
                        { name = "Range", value = "30m" }
                    }
                },
                {
                    id = 2, name = "Combat Pistol", type = "Handgun", rarity = "rare", category = "Handguns",
                    model = "WEAPON_COMBATPISTOL", price = 3200, sellPrice = 960, level = 5,
                    icon = "fas fa-gun", image = "assets/img/item/weapon_pistol.png",
                    stats = { damage = 27, accuracy = 55, range = 32, fireRate = 0.35 },
                    attributes = {
                        { name = "Damage", value = "27" },
                        { name = "Accuracy", value = "55%" },
                        { name = "Range", value = "32m" }
                    }
                },
                {
                    id = 3, name = "Heavy Pistol", type = "Handgun", rarity = "epic", category = "Handguns",
                    model = "WEAPON_HEAVYPISTOL", price = 4500, sellPrice = 1350, level = 10,
                    icon = "fas fa-gun", image = "assets/img/item/weapon_heavypistol.png",
                    stats = { damage = 40, accuracy = 60, range = 35, fireRate = 0.5 },
                    attributes = {
                        { name = "Damage", value = "40" },
                        { name = "Accuracy", value = "60%" },
                        { name = "Range", value = "35m" }
                    }
                },
                -- SUBMACHINE GUNS
                {
                    id = 4, name = "Micro SMG", type = "Submachine Gun", rarity = "common", category = "Submachine Guns",
                    model = "WEAPON_MICROSMG", price = 6200, sellPrice = 1860, level = 8,
                    icon = "fas fa-crosshairs", image = "assets/img/item/weapon_microsmg.png",
                    stats = { damage = 22, accuracy = 40, range = 25, fireRate = 0.08 },
                    attributes = {
                        { name = "Damage", value = "22" },
                        { name = "Fire Rate", value = "750 RPM" },
                        { name = "Range", value = "25m" }
                    }
                },
                {
                    id = 5, name = "SMG", type = "Submachine Gun", rarity = "rare", category = "Submachine Guns",
                    model = "WEAPON_SMG", price = 7800, sellPrice = 2340, level = 12,
                    icon = "fas fa-crosshairs", image = "assets/img/item/weapon_smg.png",
                    stats = { damage = 23, accuracy = 45, range = 28, fireRate = 0.09 },
                    attributes = {
                        { name = "Damage", value = "23" },
                        { name = "Fire Rate", value = "667 RPM" },
                        { name = "Range", value = "28m" }
                    }
                },
                -- ASSAULT RIFLES
                {
                    id = 6, name = "Assault Rifle", type = "Assault Rifle", rarity = "epic", category = "Assault Rifles",
                    model = "WEAPON_ASSAULTRIFLE", price = 12500, sellPrice = 3750, level = 20,
                    icon = "fas fa-crosshairs", image = "assets/img/item/weapon_militaryrifle.png",
                    stats = { damage = 30, accuracy = 65, range = 120, fireRate = 0.1 },
                    attributes = {
                        { name = "Damage", value = "30" },
                        { name = "Accuracy", value = "65%" },
                        { name = "Range", value = "120m" }
                    }
                },
                {
                    id = 7, name = "Carbine Rifle", type = "Assault Rifle", rarity = "legendary", category = "Assault Rifles",
                    model = "WEAPON_CARBINERIFLE", price = 15000, sellPrice = 4500, level = 25,
                    icon = "fas fa-crosshairs", image = "assets/img/item/weapon_specialcarbine.png",
                    stats = { damage = 32, accuracy = 70, range = 130, fireRate = 0.11 },
                    attributes = {
                        { name = "Damage", value = "32" },
                        { name = "Accuracy", value = "70%" },
                        { name = "Range", value = "130m" }
                    }
                },
                -- SHOTGUNS
                {
                    id = 8, name = "Pump Shotgun", type = "Shotgun", rarity = "rare", category = "Shotguns",
                    model = "WEAPON_PUMPSHOTGUN", price = 8500, sellPrice = 2550, level = 15,
                    icon = "fas fa-shotgun", image = "assets/img/item/weapon_pumpshotgun.png",
                    stats = { damage = 83, accuracy = 30, range = 15, fireRate = 1.0 },
                    attributes = {
                        { name = "Damage", value = "83" },
                        { name = "Pellets", value = "8" },
                        { name = "Range", value = "15m" }
                    }
                },
                {
                    id = 9, name = "Sawed-Off Shotgun", type = "Shotgun", rarity = "epic", category = "Shotguns",
                    model = "WEAPON_SAWNOFFSHOTGUN", price = 9800, sellPrice = 2940, level = 18,
                    icon = "fas fa-shotgun", image = "assets/img/item/weapon_sawnoffshotgun.png",
                    stats = { damage = 75, accuracy = 25, range = 12, fireRate = 0.8 },
                    attributes = {
                        { name = "Damage", value = "75" },
                        { name = "Pellets", value = "8" },
                        { name = "Range", value = "12m" }
                    }
                },
                -- SNIPER RIFLES
                {
                    id = 10, name = "Sniper Rifle", type = "Sniper Rifle", rarity = "legendary", category = "Sniper Rifles",
                    model = "WEAPON_SNIPERRIFLE", price = 25000, sellPrice = 7500, level = 35,
                    icon = "fas fa-bullseye", image = "assets/img/item/weapon_sniperrifle.png",
                    stats = { damage = 101, accuracy = 90, range = 1000, fireRate = 2.0 },
                    attributes = {
                        { name = "Damage", value = "101" },
                        { name = "Accuracy", value = "90%" },
                        { name = "Range", value = "1000m" }
                    }
                },
                -- AMMUNITION
                {
                    id = 11, name = "Pistol Ammo", type = "Ammunition", rarity = "common", category = "Ammunition",
                    model = "ammo-9", price = 50, sellPrice = 15, level = 1,
                    icon = "fas fa-bullets", image = "assets/img/item/weapon_pistol.png",
                    stats = { quantity = 50 },
                    attributes = {
                        { name = "Quantity", value = "50 rounds" },
                        { name = "Type", value = "9mm Parabellum" }
                    }
                },
                {
                    id = 12, name = "Rifle Ammo", type = "Ammunition", rarity = "common", category = "Ammunition",
                    model = "ammo-rifle", price = 75, sellPrice = 22, level = 1,
                    icon = "fas fa-bullets", image = "assets/img/item/weapon_militaryrifle.png",
                    stats = { quantity = 30 },
                    attributes = {
                        { name = "Quantity", value = "30 rounds" },
                        { name = "Type", value = "5.56x45mm NATO" }
                    }
                },
                {
                    id = 13, name = "Shotgun Shells", type = "Ammunition", rarity = "common", category = "Ammunition",
                    model = "ammo-shotgun", price = 60, sellPrice = 18, level = 1,
                    icon = "fas fa-bullets", image = "assets/img/item/weapon_pumpshotgun.png",
                    stats = { quantity = 20 },
                    attributes = {
                        { name = "Quantity", value = "20 shells" },
                        { name = "Type", value = "12 Gauge" }
                    }
                },
                -- WEAPON MODS
                {
                    id = 14, name = "Flashlight", type = "Weapon Attachment", rarity = "common", category = "Weapon Mods",
                    model = "COMPONENT_AT_PI_FLSH", price = 150, sellPrice = 45, level = 1,
                    icon = "fas fa-flashlight", image = "assets/img/item/weapon_flashlight.png",
                    attributes = {
                        { name = "Visibility", value = "+25%" },
                        { name = "Night Vision", value = "Enhanced" }
                    }
                },
                {
                    id = 15, name = "Extended Clip", type = "Weapon Attachment", rarity = "rare", category = "Weapon Mods",
                    model = "COMPONENT_PISTOL_CLIP_02", price = 300, sellPrice = 90, level = 5,
                    icon = "fas fa-magazine", image = "assets/img/item/weapon_pistol.png",
                    attributes = {
                        { name = "Capacity", value = "+50%" },
                        { name = "Reload Time", value = "-10%" }
                    }
                }
            }
        },
        ["shop2"] = {
            Items = {
                -- HEALTHY FOOD
                {
                    id = 37, name = "Nuts", type = "Healthy Food", rarity = "common", category = "Healthy Food",
                    model = "nuts", price = 12, sellPrice = 3, level = 1,
                    icon = "fas fa-seedling", image = "assets/img/item/weed_seed.png",
                    attributes = {
                        { name = "Hunger", value = "+15%" },
                        { name = "Protein", value = "+10%" }
                    }
                },
                {
                    id = 16, name = "Sandwich", type = "Healthy Food", rarity = "common", category = "Healthy Food",
                    model = "sandwich", price = 15, sellPrice = 4, level = 1,
                    icon = "fas fa-hamburger", image = "assets/img/item/weed_baggy.png",
                    attributes = {
                        { name = "Hunger", value = "+25%" },
                        { name = "Health", value = "+10%" }
                    }
                },
                -- BEVERAGES
                {
                    id = 19, name = "Energy Drink", type = "Beverage", rarity = "rare", category = "Beverages",
                    model = "energy_drink", price = 25, sellPrice = 7, level = 1,
                    icon = "fas fa-battery-full", image = "assets/img/item/wine.png",
                    attributes = {
                        { name = "Thirst", value = "+40%" },
                        { name = "Stamina", value = "+25%" },
                        { name = "Speed", value = "+10%" }
                    }
                },
                {
                    id = 33, name = "Coffee", type = "Beverage", rarity = "common", category = "Beverages",
                    model = "coffee", price = 12, sellPrice = 3, level = 1,
                    icon = "fas fa-coffee", image = "assets/img/item/whiskey.png",
                    attributes = {
                        { name = "Thirst", value = "+30%" },
                        { name = "Energy", value = "+15%" }
                    }
                },
                -- MEDICINE
                {
                    id = 21, name = "First Aid Kit", type = "Medicine", rarity = "rare", category = "Medicine",
                    model = "firstaid", price = 120, sellPrice = 36, level = 1,
                    icon = "fas fa-medkit", image = "assets/img/item/weed_baggy_empty.png",
                    attributes = {
                        { name = "Health", value = "+75%" },
                        { name = "Healing Speed", value = "Fast" }
                    }
                },
                {
                    id = 38, name = "Painkillers", type = "Medicine", rarity = "common", category = "Medicine",
                    model = "painkillers", price = 25, sellPrice = 7, level = 1,
                    icon = "fas fa-pills", image = "assets/img/item/weed_baggy.png",
                    attributes = {
                        { name = "Pain Relief", value = "+50%" },
                        { name = "Duration", value = "30min" }
                    }
                }
            }
        },
        ["shop3"] = {
            Items = {
                -- SURVEILLANCE
                {
                    id = 49, name = "Metal Detector", type = "Detection Device", rarity = "rare", category = "Surveillance",
                    model = "metal_detector", price = 350, sellPrice = 105, level = 1,
                    icon = "fas fa-search", image = "assets/img/item/weapon_metaldetector.PNG",
                    attributes = {
                        { name = "Detection Depth", value = "2 meters" },
                        { name = "Sensitivity", value = "High" },
                        { name = "Audio Alert", value = "Multi-tone" }
                    }
                }
            }
        },
        ["shop4"] = {
            Items = {
                -- TOOLS
                {
                    id = 27, name = "Advanced Toolkit", type = "Vehicle Tool", rarity = "rare", category = "Tools",
                    model = "advrepairkit", price = 200, sellPrice = 60, level = 5,
                    icon = "fas fa-toolbox", image = "assets/img/item/workbench.png",
                    attributes = {
                        { name = "Repair", value = "+100%" },
                        { name = "Uses", value = "10" }
                    }
                },
                {
                    id = 52, name = "Wrench Set", type = "Hand Tool", rarity = "common", category = "Tools",
                    model = "wrench_set", price = 35, sellPrice = 10, level = 1,
                    icon = "fas fa-wrench", image = "assets/img/item/weapon_wrench.png",
                    attributes = {
                        { name = "Size Range", value = "8-19mm" },
                        { name = "Material", value = "Chrome Steel" }
                    }
                },
                -- EMERGENCY
                {
                    id = 65, name = "Fire Extinguisher", type = "Safety Equipment", rarity = "rare", category = "Emergency",
                    model = "fire_extinguisher", price = 85, sellPrice = 25, level = 1,
                    icon = "fas fa-fire-extinguisher", image = "assets/img/item/weapon_fireextinguisher.png",
                    attributes = {
                        { name = "Type", value = "ABC Powder" },
                        { name = "Capacity", value = "2kg" }
                    }
                }
            }
        }
    },
    Locations = {
        {
            coords = vector3(21.47, -1112.34, 28.8),
            hash = "a_m_o_soucent_01",
            heading = 90.00,
            marker = "~r~ WEAPON SHOP",
            shop = "shop1",
            ui = "AMMUNITION DEPOT",
            blip = {
                ["active"] = true,
                ["name"] = "WEAPON SHOP",
                ["colour"] = 1,
                ["id"] = 110
            }
        },
        {
            coords = vector3(26.59, -1345.02, 28.5),
            hash = "a_m_m_indian_01",
            heading = 170.00,
            marker = "~g~ GROCERY STORE",
            shop = "shop2",
            ui = "24/7 SUPERMARKET",
            blip = {
                ["active"] = true,
                ["name"] = "24/7 STORE",
                ["colour"] = 2,
                ["id"] = 52
            }
        },
        {
            coords = vector3(-341.39, -1468.55, 29.61),
            hash = "a_m_y_business_02",
            heading = 270.00,
            marker = "~b~ ELECTRONICS",
            shop = "shop3",
            ui = "TECH STORE",
            blip = {
                ["active"] = true,
                ["name"] = "ELECTRONICS",
                ["colour"] = 3,
                ["id"] = 521
            }
        },
        {
            coords = vector3(-212.12, -1331.27, 29.89),
            hash = "a_m_y_mexthug_01",
            heading = 350.00,
            marker = "~o~ AUTO PARTS",
            shop = "shop4",
            ui = "MECHANIC SHOP",
            blip = {
                ["active"] = true,
                ["name"] = "AUTO PARTS",
                ["colour"] = 47,
                ["id"] = 446
            }
        }
    },
    Functions = {
        CreateBlips = function()
            for k, v in pairs(Config.Locations) do 
                if v.blip["active"] then 
                    local blip = AddBlipForCoord(v.coords)
                    SetBlipSprite(blip, v.blip["id"])
                    SetBlipScale(blip, 0.5)
                    SetBlipAsShortRange(blip, true)
                    SetBlipColour(blip, v.blip["colour"])
                    BeginTextCommandSetBlipName("STRING")
                    AddTextComponentString(v.blip["name"])
                    EndTextCommandSetBlipName(blip)
                end
            end
        end
    }
}










